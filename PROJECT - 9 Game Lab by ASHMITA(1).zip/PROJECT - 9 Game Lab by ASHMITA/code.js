var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","c4e310e0-8174-4127-a46e-0cbcc94b488b","135967ea-e1b1-462f-a987-cbc41082b8b0","d7ccb301-e379-4ac9-b403-0f6dee95a28e","f9f11e71-b261-49f7-b49e-344dad4b71ea","25b1c620-936a-4de7-8fe6-8f269136be19","8921c340-6358-46da-8713-f8f404178ee2","ddb3e159-ee4f-487f-bc0d-963217aa67ce","f60f4ea9-a255-4f8a-bb34-225d22453034"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"8khaUMYkcyLrue1OXrTjatwf2QYZsNub","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"O2vUF_xsqj3X1UdthBCgjhanATuhX_6u","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"135967ea-e1b1-462f-a987-cbc41082b8b0":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/oy1yIltrLNQf4iGHFFcLGgYTezk0.f73/category_backgrounds/background_landscape07.png","frameSize":{"x":400,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"oy1yIltrLNQf4iGHFFcLGgYTezk0.f73","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/oy1yIltrLNQf4iGHFFcLGgYTezk0.f73/category_backgrounds/background_landscape07.png"},"d7ccb301-e379-4ac9-b403-0f6dee95a28e":{"name":"enemy2","sourceUrl":null,"frameSize":{"x":498,"y":404},"frameCount":1,"looping":true,"frameDelay":12,"version":"kk7bLaGP6ZVcVpUCCbCca8HtBLvw7YSy","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":498,"y":404},"rootRelativePath":"assets/d7ccb301-e379-4ac9-b403-0f6dee95a28e.png"},"f9f11e71-b261-49f7-b49e-344dad4b71ea":{"name":"hero1","sourceUrl":null,"frameSize":{"x":317,"y":375},"frameCount":1,"looping":true,"frameDelay":12,"version":"NSSgQKI.ViOYSrMRrISyHNKWVzJEMhqV","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":317,"y":375},"rootRelativePath":"assets/f9f11e71-b261-49f7-b49e-344dad4b71ea.png"},"25b1c620-936a-4de7-8fe6-8f269136be19":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/kvqx_NCr8jVBOR7lt.z.NnCflk_DYM0n/category_animals/tiger.png","frameSize":{"x":398,"y":223},"frameCount":1,"looping":true,"frameDelay":2,"version":"kvqx_NCr8jVBOR7lt.z.NnCflk_DYM0n","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":398,"y":223},"rootRelativePath":"assets/api/v1/animation-library/gamelab/kvqx_NCr8jVBOR7lt.z.NnCflk_DYM0n/category_animals/tiger.png"},"8921c340-6358-46da-8713-f8f404178ee2":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/Puu6.MIPh3WzJZlUT8yM1hP1IdVbEJT_/category_animals/brownbear.png","frameSize":{"x":398,"y":270},"frameCount":1,"looping":true,"frameDelay":2,"version":"Puu6.MIPh3WzJZlUT8yM1hP1IdVbEJT_","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":398,"y":270},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Puu6.MIPh3WzJZlUT8yM1hP1IdVbEJT_/category_animals/brownbear.png"},"ddb3e159-ee4f-487f-bc0d-963217aa67ce":{"name":"mon","sourceUrl":null,"frameSize":{"x":101,"y":106},"frameCount":1,"looping":true,"frameDelay":12,"version":"iJt.fVTnuMABoB82b4Zl0JJoaxT4rTtb","categories":["household_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":101,"y":106},"rootRelativePath":"assets/ddb3e159-ee4f-487f-bc0d-963217aa67ce.png"},"f60f4ea9-a255-4f8a-bb34-225d22453034":{"name":"55","sourceUrl":null,"frameSize":{"x":288,"y":392},"frameCount":1,"looping":true,"frameDelay":12,"version":".UBmK5icukNzPuSOU_kiOi7Rj.wG8G4o","categories":["robots"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":288,"y":392},"rootRelativePath":"assets/f60f4ea9-a255-4f8a-bb34-225d22453034.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var gameState = "serve"
 
var backg = createSprite(200, 200);
backg.setAnimation("b");
var hero = createSprite(200,345,200,345);
hero.shapeColor="red";
var moon = createSprite(34, 365);
moon.shapeColor = "red";
var aa = createSprite(88, 357);
aa.shapeColor = "red";

var enemy1 = createSprite(200,250,10,10)
enemy1.shapeColor="red"

var enemy2 = createSprite(200,150,10,10)
enemy2.shapeColor="red"

var enemy3 = createSprite(200,50,10,10)
enemy3.shapeColor="red"

var net = createSprite(200,5,200,20)
net.shapeColor="red"

var goal =0;
var death = 0

hero.setAnimation("hero1");
hero.scale=.2;
moon.setAnimation("mon");
moon.scale = .5;
aa.setAnimation("55");
aa.scale = .2;
enemy1.setAnimation("enemy");
enemy1.scale=.1;
enemy2.setAnimation("enemy2");
enemy2.scale=.1;
enemy3.setAnimation("enemy3");
enemy3.scale=.1;

enemy1.setVelocity(-13,0);
enemy2.setVelocity(12,0);
enemy3.setVelocity(-11,0);


function draw() {
  //background(b);
  drawSprites();
  
  if(gameState == "serve")
  {
    //display welcome text
    fill("red");
    stroke("black");
    textSize(25);
    text("Welcome! Press Enter to start.",32,109);
    text("to make hero to move use arrows", 12, 152);
    
    if (gameState == "serve") {
      enemy1.setVelocity(0,0);
enemy2.setVelocity(0,0);
enemy3.setVelocity(0,0);

    }
  
  //Moving the hero on pressing enter key
  if(keyDown("enter")){
    enemy1.setVelocity(-10,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);

    gameState="play";
  }
  }
  
  if(keyDown(UP_ARROW)){
  hero.y=hero.y-3
}
 if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3
}
  if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3
}
  if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3
}
  ;
  if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  hero.x=200
  hero.y=350
  death = death+1
}
  if(hero.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  hero.x=200
  hero.y=345
  goal=goal+1
}





  createEdgeSprites();
enemy1.bounceOff(edges);
enemy2.bounceOff(edges);
enemy3.bounceOff(edges);

 
  //when hero touches bottomEdge display the text

  



textSize(20);
  fill("red");
  text("Goals:"+goal,320,350);

textSize(20)
  fill("red");
  text("death:"+death,321,373);
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
